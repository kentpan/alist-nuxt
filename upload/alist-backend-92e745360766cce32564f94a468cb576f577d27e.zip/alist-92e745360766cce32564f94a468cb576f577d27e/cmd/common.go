package cmd

import (
	"github.com/alist-org/alist/v3/internal/bootstrap/patch/v3_46_0"
	"os"
	"path/filepath"
	"strconv"

	"github.com/alist-org/alist/v3/internal/bootstrap"
	"github.com/alist-org/alist/v3/internal/bootstrap/data"
	"github.com/alist-org/alist/v3/internal/db"
	"github.com/alist-org/alist/v3/pkg/utils"
	log "github.com/sirupsen/logrus"
)

func Init() {
	bootstrap.InitConfig()
	bootstrap.Log()
	bootstrap.InitDB()

	if v3_46_0.IsLegacyRoleDetected() {
		utils.Log.Warnf("Detected legacy role format, executing ConvertLegacyRoles patch early...")
		if err := v3_46_0.ConvertLegacyRoles(); err != nil {
			utils.Log.Fatalf("Failed to convert legacy roles: %v", err)
		}
	}

	data.InitData()
	bootstrap.InitStreamLimit()
	bootstrap.InitIndex()
	if err := bootstrap.InitUpgradePatch(); err != nil {
		utils.Log.Fatalf("Failed to apply upgrade patches: %v", err)
	}
}

func Release() {
	db.Close()
}

var pid = -1
var pidFile string

func initDaemon() {
	ex, err := os.Executable()
	if err != nil {
		log.Fatal(err)
	}
	exPath := filepath.Dir(ex)
	_ = os.MkdirAll(filepath.Join(exPath, "daemon"), 0700)
	pidFile = filepath.Join(exPath, "daemon/pid")
	if utils.Exists(pidFile) {
		bytes, err := os.ReadFile(pidFile)
		if err != nil {
			log.Fatal("failed to read pid file", err)
		}
		id, err := strconv.Atoi(string(bytes))
		if err != nil {
			log.Fatal("failed to parse pid data", err)
		}
		pid = id
	}
}
